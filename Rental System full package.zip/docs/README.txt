Installation and Usage Guide

1. Import database.sql
2. Run on XAMPP
3. Login as Admin
