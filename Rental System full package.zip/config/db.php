<?php
$conn=mysqli_connect("localhost","root","","rental_system");
if(!$conn){die("DB Error");}
session_start();
?>